package com.example.foxchrome

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import org.mozilla.geckoview.WebResponse
import java.io.File

class Tab(val session: GeckoSession) {
    var title: String = "New tab"
    var url: String = ""
    var canBack = false
    var canForward = false
}

class MainActivity : AppCompatActivity() {

    companion object {
        private var sRuntime: GeckoRuntime? = null
        private const val HOME = "https://www.google.com"
        private const val AMO = "https://addons.mozilla.org/en-US/android/"
        private const val REQ_PICK_XPI = 42
    }

    private lateinit var geckoView: GeckoView
    private lateinit var urlBar: EditText
    private lateinit var tabStrip: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var btnBack: TextView
    private lateinit var btnForward: TextView

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null

    private fun runtime(): GeckoRuntime =
        sRuntime ?: GeckoRuntime.create(applicationContext).also { sRuntime = it }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        geckoView = findViewById(R.id.geckoView)
        urlBar = findViewById(R.id.urlBar)
        tabStrip = findViewById(R.id.tabStrip)
        progress = findViewById(R.id.progress)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)

        btnBack.setOnClickListener { current?.session?.goBack() }
        btnForward.setOnClickListener { current?.session?.goForward() }
        findViewById<View>(R.id.btnReload).setOnClickListener { current?.session?.reload() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlBar.setOnEditorActionListener { v, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                current?.session?.loadUri(normalize(v.text.toString()))
                v.clearFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            } else false
        }

        setupExtensionPrompts()

        createTab(intent?.dataString ?: HOME)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.dataString?.let { createTab(it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = current
        when {
            t != null && t.canBack -> t.session.goBack()
            tabs.size > 1 && t != null -> closeTab(t)
            else -> super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ tabs

    private fun createTab(url: String) {
        val session = GeckoSession()
        val tab = Tab(session)

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(s: GeckoSession, title: String?) {
                tab.title = title ?: tab.url
                updateTabStrip()
            }

            override fun onExternalResponse(s: GeckoSession, response: WebResponse) {
                if (isXpi(response.uri)) {
                    installFromUrl(response.uri)
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(response.uri)))
                    } catch (e: Exception) {
                        toast("Can't open ${response.uri}")
                    }
                }
            }

            override fun onCloseRequest(s: GeckoSession) {
                closeTab(tab)
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                s: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>
            ) {
                tab.url = url ?: ""
                if (tab === current) urlBar.setText(tab.url)
            }

            override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) {
                tab.canBack = canGoBack
                if (tab === current) updateNav()
            }

            override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) {
                tab.canForward = canGoForward
                if (tab === current) updateNav()
            }

            // Clicking an .xpi link (e.g. on addons.mozilla.org) installs it.
            override fun onLoadRequest(
                s: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                if (isXpi(request.uri)) {
                    installFromUrl(request.uri)
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return null
            }

            // target=_blank / window.open: load in the same tab (keeps things simple).
            override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                s.loadUri(uri)
                return null
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(s: GeckoSession, url: String) {
                if (tab === current) {
                    progress.progress = 0
                    progress.visibility = View.VISIBLE
                }
            }

            override fun onProgressChange(s: GeckoSession, p: Int) {
                if (tab === current) progress.progress = p
            }

            override fun onPageStop(s: GeckoSession, success: Boolean) {
                if (tab === current) progress.visibility = View.INVISIBLE
            }
        }

        tabs.add(tab)
        switchTo(tab)
        session.loadUri(normalize(url))
    }

    private fun switchTo(tab: Tab) {
        current = tab
        if (!tab.session.isOpen) tab.session.open(runtime())
        geckoView.releaseSession()
        geckoView.setSession(tab.session)
        urlBar.setText(tab.url)
        progress.visibility = View.INVISIBLE
        updateNav()
        updateTabStrip()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        val wasCurrent = tab === current
        tabs.removeAt(idx)
        if (wasCurrent) {
            geckoView.releaseSession()
            current = null
        }
        tab.session.close()
        if (tabs.isEmpty()) {
            createTab(HOME)
        } else if (wasCurrent) {
            switchTo(tabs[minOf(idx, tabs.size - 1)])
        } else {
            updateTabStrip()
        }
    }

    private fun updateNav() {
        val t = current
        btnBack.alpha = if (t?.canBack == true) 1f else 0.35f
        btnForward.alpha = if (t?.canForward == true) 1f else 0.35f
    }

    private fun updateTabStrip() {
        tabStrip.removeAllViews()
        for (t in tabs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), 0, dp(2), 0)
                setBackgroundColor(if (t === current) 0xFFFFFFFF.toInt() else 0xFFC8CCD2.toInt())
            }
            val title = TextView(this).apply {
                text = t.title.ifBlank { "New tab" }
                maxLines = 1
                maxWidth = dp(140)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(0xFF202124.toInt())
                setOnClickListener { switchTo(t) }
            }
            val close = TextView(this).apply {
                text = "✕"
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setOnClickListener { closeTab(t) }
            }
            row.addView(title)
            row.addView(close)
            tabStrip.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    .apply { setMargins(0, dp(6), dp(2), 0) }
            )
        }
        val plus = TextView(this).apply {
            text = "＋"
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { createTab(HOME) }
        }
        tabStrip.addView(plus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------ menu

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "New tab")
            menu.add(0, 2, 1, "Get Firefox add-ons")
            menu.add(0, 3, 2, "Install extension from URL")
            menu.add(0, 4, 3, "Install extension from file (.xpi)")
            menu.add(0, 5, 4, "Manage extensions")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> createTab(HOME)
                    2 -> current?.session?.loadUri(AMO)
                    3 -> promptInstallUrl()
                    4 -> pickXpi()
                    5 -> showExtensions()
                }
                true
            }
            show()
        }
    }

    // ------------------------------------------------------------------ Firefox extensions

    private fun isXpi(uri: String?): Boolean =
        uri != null && uri.substringBefore('?').endsWith(".xpi", ignoreCase = true)

    private fun extName(ext: WebExtension): String = ext.metaData?.name ?: ext.id

    /** Shows the "Add extension?" dialog whenever Gecko asks to install one. */
    private fun setupExtensionPrompts() {
        runtime().webExtensionController.setPromptDelegate(object : WebExtensionController.PromptDelegate {
            override fun onInstallPrompt(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>
            ): GeckoResult<AllowOrDeny>? {
                val result = GeckoResult<AllowOrDeny>()
                runOnUiThread {
                    val perms = (permissions.toList() + origins.toList())
                    val msg = if (perms.isEmpty()) "This extension requests no special permissions."
                    else "It requires permission to:\n\n" + perms.joinToString("\n") { "• $it" }
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Add ${extName(extension)}?")
                        .setMessage(msg)
                        .setPositiveButton("Add") { _, _ -> result.complete(AllowOrDeny.ALLOW) }
                        .setNegativeButton("Cancel") { _, _ -> result.complete(AllowOrDeny.DENY) }
                        .setOnCancelListener { result.complete(AllowOrDeny.DENY) }
                        .show()
                }
                return result
            }
        })
    }

    private fun installFromUrl(uri: String) {
        runtime().webExtensionController.install(uri).accept(
            { ext -> toast(if (ext != null) "Installed ${extName(ext)}" else "Installed") },
            { e -> toast("Install failed: ${e?.message ?: "unknown error"}") }
        )
    }

    private fun promptInstallUrl() {
        val input = EditText(this).apply {
            hint = "https://…/extension.xpi"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Install extension from URL")
            .setView(input)
            .setPositiveButton("Install") { _, _ ->
                val u = input.text.toString().trim()
                if (u.isNotEmpty()) installFromUrl(u)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickXpi() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_PICK_XPI)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK_XPI && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val out = File(cacheDir, "picked-${System.currentTimeMillis()}.xpi")
                contentResolver.openInputStream(uri)!!.use { input ->
                    out.outputStream().use { input.copyTo(it) }
                }
                installFromUrl("file://" + out.absolutePath)
            } catch (e: Exception) {
                toast("Could not read file: ${e.message}")
            }
        }
    }

    private fun showExtensions() {
        val controller = runtime().webExtensionController
        controller.list().accept(
            { list ->
                val exts: List<WebExtension> = list ?: emptyList()
                if (exts.isEmpty()) {
                    toast("No extensions installed")
                } else {
                    val labels = exts.map {
                        extName(it) + if (it.metaData?.enabled == false) "  (disabled)" else ""
                    }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("Extensions")
                        .setItems(labels) { _, i -> extensionActions(exts[i]) }
                        .setNegativeButton("Close", null)
                        .show()
                }
            },
            { e -> toast("Could not list extensions: ${e?.message}") }
        )
    }

    private fun extensionActions(ext: WebExtension) {
        val controller = runtime().webExtensionController
        val enabled = ext.metaData?.enabled != false
        val items = arrayOf(if (enabled) "Disable" else "Enable", "Remove")
        AlertDialog.Builder(this)
            .setTitle(extName(ext))
            .setItems(items) { _, which ->
                if (which == 0) {
                    val r = if (enabled) controller.disable(ext, WebExtensionController.EnableSource.USER)
                    else controller.enable(ext, WebExtensionController.EnableSource.USER)
                    r.accept(
                        { toast(if (enabled) "Disabled" else "Enabled") },
                        { e -> toast("Failed: ${e?.message}") }
                    )
                } else {
                    controller.uninstall(ext).accept(
                        { toast("Removed ${extName(ext)}") },
                        { e -> toast("Failed: ${e?.message}") }
                    )
                }
            }
            .show()
    }

    // ------------------------------------------------------------------ helpers

    private fun normalize(input: String): String {
        val s = input.trim()
        return when {
            s.isEmpty() -> HOME
            s.startsWith("http://") || s.startsWith("https://") ||
                s.startsWith("about:") || s.startsWith("file://") -> s
            s.contains(" ") || !s.contains(".") ->
                "https://www.google.com/search?q=" + Uri.encode(s)
            else -> "https://$s"
        }
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
}
