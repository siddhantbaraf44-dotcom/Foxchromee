# FoxChrome

A Chrome-style Android browser built on Mozilla **GeckoView** (the Firefox engine),
which lets you install **Firefox extensions (.xpi / WebExtensions)**.

## Features
- Chrome-like UI: tab strip, address/search bar, back / forward / reload, ⋮ menu
- Multiple tabs, open links from other apps (http/https intent filter)
- Firefox extensions:
  - Menu → **Get Firefox add-ons** (opens addons.mozilla.org) – tap an .xpi / "Add to Firefox"
  - Menu → **Install extension from URL** (direct .xpi link)
  - Menu → **Install extension from file (.xpi)**
  - Menu → **Manage extensions** (enable / disable / remove)
  - Permission prompt shown before each install

## Build the APK with GitHub Actions
1. Create a new GitHub repo and push the contents of this folder.
2. Go to **Actions → Build APK** (runs on every push, or click *Run workflow*).
3. Download the `FoxChrome-debug-apk` artifact → unzip → install `app-debug.apk`.

Workflow file: `.github/workflows/build-apk.yml`

## Build locally
Needs JDK 17, Android SDK and Gradle 8.5: `gradle assembleDebug`

## Notes / limits
- Content-script / blocker extensions (uBlock Origin, dark readers, etc.) work.
  Extension toolbar popups and the `tabs` API are not wired up yet.
- GeckoView version is set in `gradle.properties` (`geckoviewVersion=126.+`).
  If you bump it to 128+, the install-prompt callback in `MainActivity.kt`
  (`onInstallPrompt`) was replaced upstream by `onInstallPromptRequest`.
- APK is large (~100 MB) because it bundles the whole Firefox engine.
